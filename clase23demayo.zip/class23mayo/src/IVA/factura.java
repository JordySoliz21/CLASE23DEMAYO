package IVA;

public class factura {
private producto p;
private int cant;
public factura(producto p, int cant) {
	super();
	this.p = p;
	this.cant = cant;
}
public double calcSubTotal() {
	return p.precioConIVA()*cant;
}
public void imprimir_factura() {
	System.out.println("Factura:");
	System.out.println("Producto: " + p.getNombre());
	System.out.println("Cantidad: " + cant);
	System.out.println("Precio unitario (SIN IVA): " + p.getPrecioSinIva());
	System.out.println("IVA: " + p.calcIVA());
	System.out.println("Precio unitario (CON IVA): " + p.precioConIVA());
	System.out.println("Sub-Total: " + calcSubTotal());
 }
}

