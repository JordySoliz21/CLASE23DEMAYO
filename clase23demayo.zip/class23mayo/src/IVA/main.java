package IVA;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		Scanner tc = new Scanner(System.in);

		System.out.println("Por favor ingrese aquí el nombre del producto: ");
		String nombre = tc.nextLine();
		System.out.println("Por favor ingrese aquí el precio del producto: ");
		double precio = tc.nextDouble();
		System.out.println("Por favor ingrese aquí la cantidad del producto: ");
		int cant = tc.nextInt();
		
		producto pro = new producto(nombre,precio);
		factura fact = new factura(pro,cant);
		fact.imprimir_factura();
	}

}
